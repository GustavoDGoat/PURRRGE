const firebaseConfig = {
  apiKey: "AIzaSyDgV-0uGzndNh7Kcfyxu_GwHdbLGPPsG0k",
  authDomain: "purge-extension.firebaseapp.com",
  projectId: "purge-extension",
  storageBucket: "purge-extension.firebasestorage.app",
  messagingSenderId: "983930555373",
  appId: "1:983930555373:web:dd8f020142cbe4c6c875e4"
};